package com.example.springboot_project.Model.Database;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity(name = "subject")
public class SubjectModel {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int subjectId;
    private String batchNo;
    private String code;
    private String moduleName;

    public SubjectModel(int subjectId, String batchNo, String code, String moduleName) {
        this.subjectId = subjectId;
        this.batchNo = batchNo;
        this.code = code;
        this.moduleName = moduleName;
    }

    public SubjectModel() {

    }

    public int getSubjectId() {
        return subjectId;
    }

    public void setSubjectId(int subjectId) {
        this.subjectId = subjectId;
    }

    public String getBatchNo() {
        return batchNo;
    }

    public void setBatchNo(String name) {
        this.batchNo = name;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String level) {
        this.code = level;
    }

    public String getModuleName() {
        return moduleName;
    }

    public void setModuleName(String type) {
        this.moduleName = type;
    }

    @Override
    public String toString() {
        return "SubjectModel{" +
                "subjectId=" + subjectId +
                ", topic='" + batchNo + '\'' +
                ", code='" + code + '\'' +
                ", moduleName='" + moduleName + '\'' +
                '}';
    }
}
