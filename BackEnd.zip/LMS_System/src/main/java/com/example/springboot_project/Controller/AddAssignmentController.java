package com.example.springboot_project.Controller;

import com.example.springboot_project.Interface.ResponseCode;
import com.example.springboot_project.Model.Database.AddAssignmentModule;
import com.example.springboot_project.Model.Database.SubjectModuleModel;
import com.example.springboot_project.Model.Responses.ResponseModel;
import com.example.springboot_project.Services.AddAssignmentService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.server.ResponseStatusException;

@RestController
@RequestMapping("/api/assignment")
public class AddAssignmentController {

    @Autowired
    private AddAssignmentService addAssignmentService;

    @PostMapping("/add/Assignment")
    public ResponseModel AddNewAssignment(@RequestParam("data") String assignmentModule, @RequestPart(value = "file") MultipartFile file) {
        try {
            ObjectMapper objectMapper = new ObjectMapper();
            AddAssignmentModule addAssignmentModule = objectMapper.readValue(assignmentModule,AddAssignmentModule.class);
            addAssignmentService.addAssignment(addAssignmentModule,file);

            ResponseModel responseModel = new ResponseModel(
                    ResponseCode.OK,
                    null,
                    "Successfully Added Assignment Information",
                    null
            );

            return responseModel;
        } catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Internal Server Error");
        }
    }

    @PutMapping("/update/Assignment")
    public ResponseModel UpdateAssignment(@RequestBody AddAssignmentModule addAssignmentModule) {
        try {
            addAssignmentService.updateAssignmentDetails(addAssignmentModule);

            ResponseModel responseModel = new ResponseModel(
                    ResponseCode.OK,
                    null,
                    "Successfully Updated Assignment Information",
                    null
            );

            return responseModel;
        } catch (api.project.Exception.ObjectNotFoundException e) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, e.getMessage());
        } catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Internal Server Error");
        }
    }

    @GetMapping("/getAll/Assignment")
    public ResponseModel GetAllAssignmentInfo() {
        try {

            ResponseModel responseModel = new ResponseModel(
                    ResponseCode.OK,
                    addAssignmentService.getAllAssignment(),
                    "Successfully Got Assignment Info",
                    null
            );

            return responseModel;
        } catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Internal Server Error");
        }
    }

    @GetMapping("/get/Assignment/{id}")
    public ResponseModel GetBatchAssignments(@PathVariable int id) {
        try {
            ResponseModel responseModel = new ResponseModel(
                    ResponseCode.OK,
                    addAssignmentService.getOneAssignmentModule(id),
                    "Successfully Retrieved Assignment Info",
                    null
            );
            return responseModel;
        } catch (api.project.Exception.ObjectNotFoundException e) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, e.getMessage());
        } catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Internal Server Error");
        }
    }

    @DeleteMapping(value = "/deleteAssignment/{id}")
    public ResponseModel DeleteAssignment(@PathVariable int id) {
        try {
            addAssignmentService.deleteAssignment(id);

            ResponseModel responseModel = new ResponseModel(
                    ResponseCode.OK,
                    null,
                    "Successfully Deleted Assignment Info",
                    null
            );
            return responseModel;
        } catch (api.project.Exception.ObjectNotFoundException e) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, e.getMessage());
        } catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Internal Server Error");
        }
    }
}
