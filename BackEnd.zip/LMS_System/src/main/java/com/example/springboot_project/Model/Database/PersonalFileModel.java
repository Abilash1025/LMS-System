package com.example.springboot_project.Model.Database;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity(name = "personal")
public class PersonalFileModel {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int personalId;
    private String userName;
    private String topic;
    private String description;
    private String type;
    private String doc;

    public PersonalFileModel() {
    }

    public PersonalFileModel(int personalId, String userName, String topic, String description, String type, String doc) {
        this.personalId = personalId;
        this.userName = userName;
        this.topic = topic;
        this.description = description;
        this.type = type;
        this.doc = doc;
    }

    public int getPersonalId() {
        return personalId;
    }

    public void setPersonalId(int personalId) {
        this.personalId = personalId;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getTopic() {
        return topic;
    }

    public void setTopic(String topic) {
        this.topic = topic;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getDoc() {
        return doc;
    }

    public void setDoc(String doc) {
        this.doc = doc;
    }

    @Override
    public String toString() {
        return "personalFileModel{" +
                "personalId=" + personalId +
                ", userName='" + userName + '\'' +
                ", topic='" + topic + '\'' +
                ", description='" + description + '\'' +
                ", type='" + type + '\'' +
                ", doc='" + doc + '\'' +
                '}';
    }
}
