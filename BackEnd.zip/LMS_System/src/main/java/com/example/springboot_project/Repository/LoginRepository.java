package com.example.springboot_project.Repository;

import com.example.springboot_project.Model.Database.LoginModel;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;

import javax.transaction.Transactional;

public interface LoginRepository extends JpaRepository<LoginModel,Integer> {

    boolean existsByUserName(String Name);

    LoginModel findByUserName(String Name);



    @Transactional
    @Modifying
    void deleteByUserId(int id);
}
