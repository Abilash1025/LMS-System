package com.example.springboot_project.Services;

import com.example.springboot_project.Model.Database.PersonalFileModel;
import com.example.springboot_project.Repository.PersonalFileRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

@Service
public class PersonalFileServices {

    @Autowired
    private PersonalFileRepository personalFileRepository;

    @Autowired
    private AmazonService amazonService;

    public List getParticularUserFile(String username) throws api.project.Exception.ObjectNotFoundException {
        if (personalFileRepository.existsByUserName(username)) {
            List<PersonalFileModel> personalFileModel = personalFileRepository.findByUserName(username);


            return personalFileModel;
        } else {
            throw new api.project.Exception.ObjectNotFoundException("Incorrect User ID to Retrieved a Personal File Info");
        }
    }

    public void addPersonal(PersonalFileModel personalFileModel, String username, MultipartFile file) throws Exception {
        if (file != null) {

            String fileUrl = String.valueOf(this.amazonService.UploadFile(file, "personal").get());

            if (fileUrl != "") {
                PersonalFileModel fileModel=new PersonalFileModel();

                fileModel.setDoc(fileUrl);
                fileModel.setDescription(personalFileModel.getDescription());
                fileModel.setTopic(personalFileModel.getTopic());
                fileModel.setType(personalFileModel.getType());
                fileModel.setUserName(username);

                personalFileRepository.save(fileModel);
            } else {
                throw new Exception("Amazon S3 issue in storing image");
            }
        }



    }

    public void deletePersonalFile(int id) throws api.project.Exception.ObjectNotFoundException {
        if(personalFileRepository.existsById(id)){
            personalFileRepository.deleteById(id);
        }
        else{
            throw new api.project.Exception.ObjectNotFoundException("Id is not found");
        }
    }
}
