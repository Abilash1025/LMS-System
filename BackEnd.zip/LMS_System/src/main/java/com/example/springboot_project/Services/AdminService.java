package com.example.springboot_project.Services;

import com.example.springboot_project.Model.Database.AdminModel;
import com.example.springboot_project.Model.Database.AssignmentModel;
import com.example.springboot_project.Model.Database.LoginModel;
import com.example.springboot_project.Model.Database.SubjectModuleModel;
import com.example.springboot_project.Model.Responses.LoginResponseModel;
import com.example.springboot_project.Repository.AdminRepository;
import com.example.springboot_project.Repository.LoginRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.util.ArrayList;
import java.util.List;

@Service
public class AdminService {
    @Autowired
    private AdminRepository adminRepository;

    @Autowired
    private AmazonService amazonService;

    @Autowired
    private LoginRepository loginRepository;
    public void addAdmin(AdminModel adminModel, MultipartFile file) throws Exception  {
        if(!loginRepository.existsByUserName(adminModel.getEmail())){
            if (file != null) {

                String fileUrl = String.valueOf(this.amazonService.UploadFile(file, "admin").get());

                if (fileUrl != "") {
                    AdminModel model = new AdminModel();

                    LoginModel loginModel=new LoginModel();

                    model.setImage(fileUrl);
                    model.setFullName(adminModel.getFullName());
                    model.setGender(adminModel.getGender());
                    model.setEmail(adminModel.getEmail());
                    model.setAddress(adminModel.getAddress());
                    model.setTelephoneNumber(adminModel.getTelephoneNumber());
                    model.setPassword(adminModel.getPassword());

                    adminRepository.save(model);


                    loginModel.setPassword(adminModel.getPassword());
                    loginModel.setUserName(adminModel.getEmail());
                    loginModel.setUserId(model.getAdminId());
                    loginModel.setBatchNo("NOTHING");
                    loginModel.setRole("ADMIN");

                    loginRepository.save(loginModel);

                } else {
                    throw new Exception("Amazon S3 issue in storing image");
                }
            }

        }
        else {

            throw new com.example.springboot_project.Exception.AlreadyExistException("The Email id is already existed");
        }
    }

    public List getAllAdmin(){
        List<AdminModel> adminModels = adminRepository.findAll();

        return adminModels;
    }

    public List getAdminById(int id) throws api.project.Exception.ObjectNotFoundException {
        if (adminRepository.existsByAdminId(id)) {
            AdminModel adminModel = adminRepository.findByAdminId(id);
            List admin = new ArrayList();
            admin.add(adminModel);
            return admin;
        } else {
            throw new api.project.Exception.ObjectNotFoundException("Incorrect Admin Id to Retrieved a Assignment Info");
        }
    }
    public void updateAdminDetails(AdminModel admin, MultipartFile file) throws Exception {
        if (adminRepository.existsById(admin.getAdminId())) {


            AdminModel adminModel = adminRepository.findByAdminId(admin.getAdminId());
                if (file != null) {
                    String fileUrl = String.valueOf(this.amazonService.UploadFile(file, "admin").get());
                    adminModel.setImage(fileUrl);
                }

            if (admin.getFullName() != null && admin.getFullName().length() > 0) {
                adminModel.setFullName(admin.getFullName());
            }
            if (admin.getTelephoneNumber() != null && admin.getTelephoneNumber().length() > 0) {
                adminModel.setTelephoneNumber(admin.getTelephoneNumber());
            }
            if (admin.getGender() != null && admin.getGender().length() > 0) {
                adminModel.setGender(admin.getGender());
            }
            if (admin.getAddress() != null && admin.getAddress().length() > 0) {
                adminModel.setAddress(admin.getAddress());
            }


            adminRepository.save(adminModel);


        } else {
            throw new api.project.Exception.ObjectNotFoundException("Admin info not found");
        }
    }

    public void updatePasswordDetails(String password, String username) throws Exception {
        if (adminRepository.existsByEmail(username)) {

            AdminModel adminModel = adminRepository.findByEmail(username);
            LoginModel loginModel=loginRepository.findByUserName(username);
            if (password != null && password.length() > 0) {
                adminModel.setPassword(password);
            }
            loginModel.setPassword(password);

            adminRepository.save(adminModel);
            loginRepository.save(loginModel);

        } else {
            throw new api.project.Exception.ObjectNotFoundException("Admin info not found");
        }
    }

    public void deleteAdmin(int id) throws api.project.Exception.ObjectNotFoundException {
        if(adminRepository.existsById(id)){
            adminRepository.deleteById(id);
            loginRepository.deleteByUserId(id);
        }
        else{
            throw new api.project.Exception.ObjectNotFoundException("Id is not found");
        }
    }

    public List login(String userName, String password) throws api.project.Exception.ObjectNotFoundException {
        if (loginRepository.existsByUserName(userName)) {
            LoginModel loginModel = loginRepository.findByUserName(userName);

            if (password.equals(loginModel.getPassword())) {
                LoginResponseModel loginResponseModel = new LoginResponseModel();

                loginResponseModel.setUsername(loginModel.getUserName());
                loginResponseModel.setRole(loginModel.getRole());
                loginResponseModel.setUserID(loginModel.getUserId());
                loginResponseModel.setBatch(loginModel.getBatchNo());

                List<LoginResponseModel> login = new ArrayList<>();
                login.add(loginResponseModel);
                return login;
            }
            else {
                throw new api.project.Exception.ObjectNotFoundException("password is incorrect");
            }
        } else {
            throw new api.project.Exception.ObjectNotFoundException("username is incorrect");
        }
    }
}

