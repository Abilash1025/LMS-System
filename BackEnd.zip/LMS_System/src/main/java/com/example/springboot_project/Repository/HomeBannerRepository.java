package com.example.springboot_project.Repository;

import com.example.springboot_project.Model.Database.HomeBannerModel;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface HomeBannerRepository extends JpaRepository<HomeBannerModel, Integer> {

    HomeBannerModel findByHomeBannerId(int id);
}
