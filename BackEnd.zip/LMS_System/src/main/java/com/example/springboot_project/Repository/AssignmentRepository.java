package com.example.springboot_project.Repository;

import com.example.springboot_project.Model.Database.AssignmentModel;
import com.example.springboot_project.Model.Database.UserModel;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import javax.transaction.Transactional;
import java.util.List;

@Repository
public interface AssignmentRepository extends JpaRepository<AssignmentModel,Integer> {

    boolean existsByBatchAndStatusAndStudentId(String batch,String Status,int id);
    boolean existsByBatchAndStudentId(String batch,int id);

    boolean existsByAssigmentFileId(int id);
        @Transactional
        @Modifying
        void deleteAllByAssigmentFileId(int id);

        List<AssignmentModel> findAllByAssigmentFileIdAndStatus(int id,String staus);
    List<AssignmentModel> findAllByAssigmentFileId(int id);

        List<AssignmentModel> findByBatchAndStatusAndStudentId(String batch,String Status,int id);
      List<AssignmentModel> findByBatchAndStudentIdAndStatusOrStatus(String batch,int id,String Status,String status);
    List<AssignmentModel> findByBatchAndStudentIdAndStatus(String batch,int id,String status);
        AssignmentModel findByAssignmentId(int id);


}
