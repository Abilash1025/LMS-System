package com.example.springboot_project.Controller;

import com.example.springboot_project.Interface.ResponseCode;
import com.example.springboot_project.Model.Responses.ResponseModel;
import com.example.springboot_project.Services.QuotesService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

@RestController
@RequestMapping("/api/quotes")
public class QuotesController {

    @Autowired
    private QuotesService quotesService;

    @GetMapping("/get/quotes")
    public ResponseModel getQuotes()  {
        try {

            quotesService.getAllQuotes();

            ResponseModel responseModel = new ResponseModel(
                    ResponseCode.OK,
                    quotesService.getAllQuotes(),
                    "Successfully Got Quotes Information",
                    null
            );

            return responseModel;
        } catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Internal Server Error");
        }
    }
}
