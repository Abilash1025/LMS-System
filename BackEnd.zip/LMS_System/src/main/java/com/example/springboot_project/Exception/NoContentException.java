package com.example.springboot_project.Exception;

public class NoContentException extends Exception {

    public NoContentException(String message) {
        super(message);
    }
}
