package com.example.springboot_project.Model.Database;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity(name = "footer")
public class FooterModel {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int footerId;
    private String copyRight;
    private String fbLink;
    private String twitterLink;
    private String phone;

    public FooterModel() {
    }

    public FooterModel(int footerId, String copyRight, String fbLink, String twitterLink, String phone) {
        this.footerId = footerId;
        this.copyRight = copyRight;
        this.fbLink = fbLink;
        this.twitterLink = twitterLink;
        this.phone = phone;
    }

    public int getFooterId() {
        return footerId;
    }

    public void setFooterId(int footerId) {
        this.footerId = footerId;
    }

    public String getCopyRight() {
        return copyRight;
    }

    public void setCopyRight(String copyRight) {
        this.copyRight = copyRight;
    }

    public String getFbLink() {
        return fbLink;
    }

    public void setFbLink(String fbLink) {
        this.fbLink = fbLink;
    }

    public String getTwitterLink() {
        return twitterLink;
    }

    public void setTwitterLink(String twitterLink) {
        this.twitterLink = twitterLink;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    @Override
    public String toString() {
        return "FooterModel{" +
                "footerId=" + footerId +
                ", copyRight='" + copyRight + '\'' +
                ", fbLink='" + fbLink + '\'' +
                ", twitterLink='" + twitterLink + '\'' +
                ", phone='" + phone + '\'' +
                '}';
    }
}
