package com.example.springboot_project.Repository;

import com.example.springboot_project.Model.Database.AdminModel;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface AdminRepository extends JpaRepository<AdminModel,Integer> {

    AdminModel findByAdminId(int id);

    boolean existsByAdminId(int id);

    AdminModel findByEmail(String name);

    boolean existsByEmail(String name);
}
