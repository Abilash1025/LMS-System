package com.example.springboot_project.Controller;


import com.example.springboot_project.Interface.ResponseCode;
import com.example.springboot_project.Model.Database.AdminModel;
import com.example.springboot_project.Model.Responses.ResponseModel;
import com.example.springboot_project.Services.AssignmentService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.server.ResponseStatusException;

@RestController
@RequestMapping("/api/assignment")
public class AssignmentController {

    @Autowired
    private AssignmentService assignmentService;

    @GetMapping("/get/particularAssignment/{batch}/{id}")
    public ResponseModel getParticularAssignments(@PathVariable String batch,@PathVariable int id)  {
        try {

            assignmentService.getBatchAssignmentModule(batch,id);
            ResponseModel responseModel = new ResponseModel(
                    ResponseCode.OK,
                    assignmentService.getBatchAssignmentModule(batch,id),
                    "Successfully Got Assignment Information",
                    null
            );

            return responseModel;
        } catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Internal Server Error");
        }
    }
    @GetMapping("/get/particularIdAssignment/{id}")
    public ResponseModel getParticularIdAssignments(@PathVariable int id)  {
        try {

            assignmentService.getAssignmentById(id);
            ResponseModel responseModel = new ResponseModel(
                    ResponseCode.OK,
                    assignmentService.getAssignmentById(id),
                    "Successfully Got Assignment Information",
                    null
            );

            return responseModel;
        } catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Internal Server Error");
        }
    }


    @GetMapping("/get/GradedParticularIdAssignment/{id}")
    public ResponseModel getGratedParticularIdAssignments(@PathVariable int id)  {
        try {

            assignmentService.getGradedAssignmentById(id);
            ResponseModel responseModel = new ResponseModel(
                    ResponseCode.OK,
                    assignmentService.getGradedAssignmentById(id),
                    "Successfully Got Assignment Information",
                    null
            );

            return responseModel;
        } catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Internal Server Error");
        }
    }
    @GetMapping("/get/SubmittedAssignments/{batch}/{id}")
    public ResponseModel getSubmittedAssignments(@PathVariable String batch,@PathVariable int id) {
        try {

            assignmentService.getSubmittedAssignmentModule(batch,id);
            ResponseModel responseModel = new ResponseModel(
                    ResponseCode.OK,
                    assignmentService.getSubmittedAssignmentModule(batch,id),
                    "Successfully Got Assignment Information",
                    null
            );

            return responseModel;
        } catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Internal Server Error");
        }
    }

    @PutMapping("/submit/Assignment")
    public ResponseModel SubmitAssignment(@RequestParam("date") String date,@RequestParam("id") int id, @RequestPart(value = "file") MultipartFile file) {
        try {

            assignmentService.updateAssignmentDetails(id,date,file);

            ResponseModel responseModel = new ResponseModel(
                    ResponseCode.OK,
                    null,
                    "Successfully Submitted the Assigment",
                    null
            );

            return responseModel;
        } catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Internal Server Error");
        }
    }

    @PutMapping("/grade/Assignment")
    public ResponseModel gradeAssignment(@RequestParam("comment") String comment,@RequestParam("grade") String grade,@RequestParam("id") int id) {
        try {

            assignmentService.gradeAssignmentDetails(id,comment,grade);

            ResponseModel responseModel = new ResponseModel(
                    ResponseCode.OK,
                    null,
                    "Successfully Graded the Assigment",
                    null
            );

            return responseModel;
        } catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Internal Server Error");
        }
    }
}
