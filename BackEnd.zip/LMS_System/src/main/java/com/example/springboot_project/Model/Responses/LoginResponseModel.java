package com.example.springboot_project.Model.Responses;

public class LoginResponseModel {

    private int userID;
    private String username;
    private String role;

    private String batch;

    public LoginResponseModel() {
    }

    public LoginResponseModel(int userID, String username, String role, String batch) {
        this.userID = userID;
        this.username = username;
        this.role = role;
        this.batch = batch;
    }

    public int getUserID() {
        return userID;
    }

    public void setUserID(int userID) {
        this.userID = userID;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public String getBatch() {
        return batch;
    }

    public void setBatch(String batch) {
        this.batch = batch;
    }

    @Override
    public String toString() {
        return "LoginResponseModel{" +
                "userID=" + userID +
                ", username='" + username + '\'' +
                ", role='" + role + '\'' +
                ", batch='" + batch + '\'' +
                '}';
    }
}
