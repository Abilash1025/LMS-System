package com.example.springboot_project.Services;

import com.example.springboot_project.Model.Database.SubjectModel;
import com.example.springboot_project.Model.Database.SubjectModuleModel;
import com.example.springboot_project.Repository.SubjectModuleRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.util.ArrayList;
import java.util.List;

@Service
public class SubjectModuleService {

    @Autowired
    private SubjectModuleRepository subjectModuleRepository;

    @Autowired
    private AmazonService amazonService;


    public void addSubjectModule(SubjectModuleModel subjectModuleModel,MultipartFile file) throws Exception {
        if (file != null) {

            String fileUrl = String.valueOf(this.amazonService.UploadFile(file, "subjectModule").get());

            if (fileUrl != "") {
                SubjectModuleModel moduleModel= new SubjectModuleModel();

                moduleModel.setDoc(fileUrl);
                moduleModel.setModule(subjectModuleModel.getModule());
                moduleModel.setBatch(subjectModuleModel.getBatch());
                moduleModel.setTopic(subjectModuleModel.getTopic());
                moduleModel.setType(subjectModuleModel.getType());

                subjectModuleRepository.save(moduleModel);
            } else {
                throw new Exception("Amazon S3 issue in storing image");
            }
        }

    }

    public List getAllSubjectModule(){
        List<SubjectModuleModel> subjectModuleModels = subjectModuleRepository.findAll();

        return subjectModuleModels;
    }

    public List getOneSubjectModule(int id) throws api.project.Exception.ObjectNotFoundException {
        if (subjectModuleRepository.existsById(id)) {
            SubjectModuleModel subjectModuleModel= subjectModuleRepository.findByModuleId(id);
            List moduleInfo = new ArrayList();
            moduleInfo.add(subjectModuleModel);

            return moduleInfo;
        } else {
            throw new api.project.Exception.ObjectNotFoundException("Incorrect Module ID to Retrieved a Module Info");
        }
    }

    public List getSubjectBatchModules(String batch,String module) throws api.project.Exception.ObjectNotFoundException {
        if (subjectModuleRepository.existsByBatchAndModule(batch,module)) {
            List<SubjectModuleModel> subjectModels = subjectModuleRepository.findByBatchAndModule(batch,module);

            return subjectModels;
        } else {
            throw new api.project.Exception.ObjectNotFoundException("Incorrect Batch Id to Retrieved a Module Info");
        }
    }


    public void updateSubjectModuleDetails(SubjectModuleModel subject) throws api.project.Exception.ObjectNotFoundException {
        if (subjectModuleRepository.existsById(subject.getModuleId())) {
            SubjectModuleModel subjectModuleModel = subjectModuleRepository.findByModuleId(subject.getModuleId());

            if (subject.getTopic() != null && subject.getTopic().length() > 0) {
                subjectModuleModel.setTopic(subject.getTopic());
            }
            if (subject.getBatch() != null && subject.getBatch().length() > 0) {
                subjectModuleModel.setBatch(subject.getBatch());
            }
            if (subject.getModule() != null && subject.getModule().length() > 0) {
                subjectModuleModel.setModule(subject.getModule());
            }
            if (subject.getType() != null && subject.getType().length() > 0) {
                subjectModuleModel.setType(subject.getType());
            }
            subjectModuleRepository.save(subjectModuleModel);

        } else {
            throw new api.project.Exception.ObjectNotFoundException("Subject Module info not found");
        }
    }

    public void deleteSubjectModule(int id) throws api.project.Exception.ObjectNotFoundException {
        if(subjectModuleRepository.existsById(id)){
            subjectModuleRepository.deleteById(id);
        }
        else{
            throw new api.project.Exception.ObjectNotFoundException("Id is not found");
        }
    }
}
