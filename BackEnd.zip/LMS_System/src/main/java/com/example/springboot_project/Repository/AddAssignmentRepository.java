package com.example.springboot_project.Repository;

import com.example.springboot_project.Model.Database.AddAssignmentModule;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface AddAssignmentRepository extends JpaRepository<AddAssignmentModule,Integer> {

    AddAssignmentModule findByAssigmentFileId(int id);

    boolean existsByBatch(String batch);

    AddAssignmentModule findAllByBatch(String batch);
}
