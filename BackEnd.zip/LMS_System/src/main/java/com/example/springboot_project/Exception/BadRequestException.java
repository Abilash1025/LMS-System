package com.example.springboot_project.Exception;

public class BadRequestException extends Exception {
    public BadRequestException(String message) {
        super(message);
    }
}
