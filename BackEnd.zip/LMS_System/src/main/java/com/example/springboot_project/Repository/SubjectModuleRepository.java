package com.example.springboot_project.Repository;

import com.example.springboot_project.Model.Database.SubjectModuleModel;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface SubjectModuleRepository extends JpaRepository<SubjectModuleModel,Integer> {

    SubjectModuleModel findByModuleId(int id);

    boolean existsByBatchAndModule(String batch,String Module);


    List<SubjectModuleModel> findByBatchAndModule(String batch, String Module);

    SubjectModuleModel findByTopic(String name);

    boolean existsByTopic(String name);
}
