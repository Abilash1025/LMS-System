package com.example.springboot_project.Repository;

import com.example.springboot_project.Model.Database.PersonalFileModel;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface PersonalFileRepository extends JpaRepository<PersonalFileModel,Integer> {

    List<PersonalFileModel> findByUserName(String username);

    boolean existsByUserName(String username);
}
