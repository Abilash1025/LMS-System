package com.example.springboot_project.Services;

import com.example.springboot_project.Model.Database.AddAssignmentModule;
import com.example.springboot_project.Model.Database.AdminModel;
import com.example.springboot_project.Model.Database.AssignmentModel;
import com.example.springboot_project.Repository.AssignmentRepository;
import com.example.springboot_project.Repository.LoginRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.util.ArrayList;
import java.util.List;

@Service
public class AssignmentService {

    @Autowired
    AssignmentRepository assignmentRepository;

    @Autowired
    AmazonService amazonService;

    @Autowired
    LoginRepository loginRepository;
    public List getBatchAssignmentModule(String batch,int id) throws api.project.Exception.ObjectNotFoundException {
        if (assignmentRepository.existsByBatchAndStatusAndStudentId(batch,"NEW",id)) {
            List<AssignmentModel> assignmentModel = assignmentRepository.findByBatchAndStatusAndStudentId(batch,"NEW",id);
            return assignmentModel;
        } else {
            throw new api.project.Exception.ObjectNotFoundException("Incorrect Assignment Id to Retrieved a Assignment Info");
        }
    }

    public List getAssignmentById(int id) throws api.project.Exception.ObjectNotFoundException {
        if (assignmentRepository.existsByAssigmentFileId(id)) {
            List<AssignmentModel> assignmentModel = assignmentRepository.findAllByAssigmentFileIdAndStatus(id,"PENDING");
            return assignmentModel;
        } else {
            throw new api.project.Exception.ObjectNotFoundException("Incorrect Assignment Id to Retrieved a Assignment Info");
        }
    }



    public List getGradedAssignmentById(int id) throws api.project.Exception.ObjectNotFoundException {
        if (assignmentRepository.existsByAssigmentFileId(id)) {
            List<AssignmentModel> assignmentModel = assignmentRepository.findAllByAssigmentFileIdAndStatus(id,"MARKED");
            return assignmentModel;
        } else {
            throw new api.project.Exception.ObjectNotFoundException("Incorrect Assignment Id to Retrieved a Assignment Info");
        }
    }

    public List getSubmittedAssignmentModule(String batch,int id) throws api.project.Exception.ObjectNotFoundException {
        if (assignmentRepository.existsByBatchAndStudentId(batch,id)) {
            List<AssignmentModel> assignmentModel = assignmentRepository.findByBatchAndStudentIdAndStatus(batch,id,"MARKED");

            return assignmentModel;
        } else {
            throw new api.project.Exception.ObjectNotFoundException("Incorrect Assignment Id to Retrieved a Assignment Info");
        }
    }

    public void updateAssignmentDetails(int id,String today,MultipartFile file) throws Exception{
        if (file != null) {

            String fileUrl = String.valueOf(this.amazonService.UploadFile(file, "submittedassignment").get());

            if (fileUrl != "") {
                AssignmentModel model=assignmentRepository.findByAssignmentId(id);

                model.setSubmittedDoc(fileUrl);
                model.setStatus("PENDING");
                model.setComment("No Comments");
                model.setMarks("Not Graded");
                model.setSubmittedTime(today);


                assignmentRepository.save(model);
            } else {
                throw new Exception("Amazon S3 issue in storing image");
            }
        }
    }

    public void gradeAssignmentDetails(int id,String comment,String grade) throws Exception{
            if (assignmentRepository.existsById(id)) {
                AssignmentModel model=assignmentRepository.findByAssignmentId(id);

                model.setComment(comment);
                model.setMarks(grade);
                model.setStatus("MARKED");



                assignmentRepository.save(model);
            } else {
                throw new Exception("Amazon S3 issue in storing image");
            }

    }



}
