package api.project.Exception;

public class ObjectNotFoundException extends Exception {
    public ObjectNotFoundException(String s) {
        super(s);
    }
}