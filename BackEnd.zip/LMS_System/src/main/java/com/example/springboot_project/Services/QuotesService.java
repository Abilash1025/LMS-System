package com.example.springboot_project.Services;

import com.example.springboot_project.Model.Database.QuotesModel;
import com.example.springboot_project.Model.Database.SubjectModel;
import com.example.springboot_project.Repository.QuotesRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class QuotesService {
    @Autowired
    private QuotesRepository quotesRepository;

    public List getAllQuotes(){


        return     quotesRepository.findAll();
    }
}

