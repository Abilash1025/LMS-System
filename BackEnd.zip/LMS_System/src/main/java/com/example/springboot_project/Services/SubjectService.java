package com.example.springboot_project.Services;

import com.example.springboot_project.Model.Database.AssignmentModel;
import com.example.springboot_project.Model.Database.SubjectModel;
import com.example.springboot_project.Repository.SubjectRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class SubjectService {

    @Autowired
    private SubjectRepository subjectRepository;

    public List addSubject (SubjectModel subjectModel){

        subjectRepository.save(subjectModel);

        List subject = new ArrayList();
        subject.add(subjectModel);
        return subject;
    }

    public List getAllSubject(){
        List<SubjectModel> subjectModels = subjectRepository.findAll();

        return subjectModels;
    }

    public List getBatchModules(String batch) throws api.project.Exception.ObjectNotFoundException {
        if (subjectRepository.existsByBatchNo(batch)) {
            List<SubjectModel> subjectModels = subjectRepository.findByBatchNo(batch);

            return subjectModels;
        } else {
            throw new api.project.Exception.ObjectNotFoundException("Incorrect Batch Id to Retrieved a Module Info");
        }
    }

    public void updateSubjectDetails(SubjectModel subject) throws api.project.Exception.ObjectNotFoundException {
        if (subjectRepository.existsById(subject.getSubjectId())) {
            SubjectModel subjectModel = subjectRepository.findBySubjectId(subject.getSubjectId());

            if (subject.getBatchNo() != null && subject.getBatchNo().length() > 0) {
                subjectModel.setBatchNo(subject.getBatchNo());
            }
            if (subject.getCode() != null && subject.getCode().length() > 0) {
                subjectModel.setCode(subject.getCode());
            }
            if (subject.getModuleName() != null && subject.getModuleName().length() > 0) {
                subjectModel.setModuleName(subject.getModuleName());
            }

            subjectRepository.save(subject);

        } else {
            throw new api.project.Exception.ObjectNotFoundException("Subject info not found");
        }
    }

    public void deleteSubject(int id) throws api.project.Exception.ObjectNotFoundException {
        if(subjectRepository.existsById(id)){
            subjectRepository.deleteById(id);
        }
        else{
            throw new api.project.Exception.ObjectNotFoundException("Id is not found");
        }
    }
}
