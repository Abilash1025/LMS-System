package com.example.springboot_project.Exception;

public class GateWayTimeOutException extends Exception {

    public GateWayTimeOutException(String message) {
        super(message);
    }
}
