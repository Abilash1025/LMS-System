package com.example.springboot_project.Repository;

import com.example.springboot_project.Model.Database.BatchModule;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface BatchRepository extends JpaRepository<BatchModule,Integer> {

    BatchModule findByBatchId(int id);


}
