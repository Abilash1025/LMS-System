package com.example.springboot_project.Services;

import com.example.springboot_project.Model.Database.AdminModel;
import com.example.springboot_project.Model.Database.LoginModel;
import com.example.springboot_project.Model.Database.UserModel;
import com.example.springboot_project.Repository.LoginRepository;
import com.example.springboot_project.Repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.util.ArrayList;
import java.util.List;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private AmazonService amazonService;
    @Autowired
    private LoginRepository loginRepository;
    public void addUser(UserModel userModel, MultipartFile file) throws Exception {
        if(!loginRepository.existsByUserName(userModel.getEmail())){
            if (file != null) {
                String fileUrl = String.valueOf(this.amazonService.UploadFile(file, "user").get());
                if (fileUrl != "") {
                    UserModel model = new UserModel();
                    LoginModel loginModel=new LoginModel();
                    model.setImage(fileUrl);
                    model.setFullName(userModel.getFullName());
                    model.setGender(userModel.getGender());
                    model.setEmail(userModel.getEmail());
                    model.setAddress(userModel.getAddress());
                    model.setTelephoneNumber(userModel.getTelephoneNumber());
                    model.setPassword(userModel.getPassword());
                    model.setBatch(userModel.getBatch());
                    userRepository.save(model);
                    loginModel.setPassword(userModel.getPassword());
                    loginModel.setUserName(userModel.getEmail());
                    loginModel.setUserId(model.getUserId());
                    loginModel.setBatchNo(userModel.getBatch());
                    loginModel.setRole("STUDENT");
                    loginRepository.save(loginModel);

                } else {
                    throw new Exception("Amazon S3 issue in storing image");
                }
            }
        }
        else {
            throw new com.example.springboot_project.Exception.AlreadyExistException("The Email id is already existed");
        }
    }
    public List getAllUser(){
        List<UserModel> userModels = userRepository.findAll();

        return userModels;
    }

    public List getUserById(int id) throws api.project.Exception.ObjectNotFoundException {
        if (userRepository.existsById(id)) {
            UserModel userModel = userRepository.findByUserId(id);
            List user = new ArrayList();
            user.add(userModel);
            return user;
        } else {
            throw new api.project.Exception.ObjectNotFoundException("Incorrect User Id to Retrieved a Assignment Info");
        }
    }
    public void updateUserDetails(UserModel model, MultipartFile file) throws Exception {
        if (userRepository.existsById(model.getUserId())) {
            UserModel userModel = userRepository.findByUserId(model.getUserId());


            if (file != null) {
                String fileUrl = String.valueOf(this.amazonService.UploadFile(file, "user").get());
                userModel.setImage(fileUrl);
            }
            else {
                throw new Exception("Amazon S3 issue in storing image");
            }

            if (model.getFullName() != null && model.getFullName().length() > 0) {
                userModel.setFullName(model.getFullName());
            }
            if (model.getTelephoneNumber() != null && model.getTelephoneNumber().length() > 0) {
                userModel.setTelephoneNumber(model.getTelephoneNumber());
            }

            if (model.getAddress() != null && model.getAddress().length() > 0) {
                userModel.setAddress(model.getAddress());
            }
            if (model.getGender() != null && model.getGender().length() > 0) {
                userModel.setGender(model.getGender());
            }


            userRepository.save(userModel);

        } else {
            throw new api.project.Exception.ObjectNotFoundException("User info not found");
        }
    }

    public void updatePasswordDetails(String password, String username) throws Exception {
        if (userRepository.existsByEmail(username)) {

            UserModel userModel = userRepository.findByEmail(username);
            LoginModel loginModel=loginRepository.findByUserName(username);
            if (password != null && password.length() > 0) {
                userModel.setPassword(password);
            }
            loginModel.setPassword(password);

            userRepository.save(userModel);
            loginRepository.save(loginModel);

        } else {
            throw new api.project.Exception.ObjectNotFoundException("Admin info not found");
        }
    }



    public void deleteUser(int id) throws api.project.Exception.ObjectNotFoundException {
        if(userRepository.existsById(id)){
            userRepository.deleteById(id);
            loginRepository.deleteByUserId(id);
        }
        else{
            throw new api.project.Exception.ObjectNotFoundException("Id is not found");
        }
    }

}
