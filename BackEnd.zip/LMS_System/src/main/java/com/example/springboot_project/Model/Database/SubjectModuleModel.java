package com.example.springboot_project.Model.Database;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity(name = "module")
public class SubjectModuleModel {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int moduleId;
    private String topic;
    private String batch;
    private String module;
    private String type;
    private String doc;

    public SubjectModuleModel(int moduleId, String topic, String batch, String module, String type, String doc) {
        this.moduleId = moduleId;
        this.topic = topic;
        this.batch = batch;
        this.module = module;
        this.type = type;
        this.doc = doc;
    }

    public SubjectModuleModel() {

    }

    public int getModuleId() {
        return moduleId;
    }

    public void setModuleId(int moduleId) {
        this.moduleId = moduleId;
    }

    public String getTopic() {
        return topic;
    }

    public void setTopic(String topic) {
        this.topic = topic;
    }

    public String getBatch() {
        return batch;
    }

    public void setBatch(String moduleName) {
        this.batch = moduleName;
    }

    public String getModule() {
        return module;
    }

    public void setModule(String level) {
        this.module = level;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getDoc() {
        return doc;
    }

    public void setDoc(String file) {
        this.doc = file;
    }

    @Override
    public String toString() {
        return "SubjectModuleModel{" +
                "moduleId=" + moduleId +
                ", topic='" + topic + '\'' +
                ", moduleName='" + batch + '\'' +
                ", level='" + module + '\'' +
                ", type='" + type + '\'' +
                ", file='" + doc + '\'' +
                '}';
    }
}
