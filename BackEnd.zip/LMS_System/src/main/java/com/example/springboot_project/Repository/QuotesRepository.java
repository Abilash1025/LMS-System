package com.example.springboot_project.Repository;

import com.example.springboot_project.Model.Database.QuotesModel;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import java.util.List;

@Repository
public interface QuotesRepository extends JpaRepository<QuotesModel,Integer> {

    @Query(value = "SELECT * FROM quotes ORDER BY RAND() LIMIT 1 ", nativeQuery = true)
    List<QuotesModel> findAll();
}
