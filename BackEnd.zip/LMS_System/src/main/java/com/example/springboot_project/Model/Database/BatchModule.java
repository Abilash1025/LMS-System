package com.example.springboot_project.Model.Database;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity(name = "batch")
public class BatchModule {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int batchId;
    private String batchNo;
    private String startDate;
    private String endDate;

    public BatchModule() {
    }

    public BatchModule(int batchId, String batchNo, String startDate, String endDate) {
        this.batchId = batchId;
        this.batchNo = batchNo;
        this.startDate = startDate;
        this.endDate = endDate;
    }

    public int getBatchId() {
        return batchId;
    }

    public void setBatchId(int batchId) {
        this.batchId = batchId;
    }

    public String getBatchNo() {
        return batchNo;
    }

    public void setBatchNo(String batchNo) {
        this.batchNo = batchNo;
    }

    public String getStartDate() {
        return startDate;
    }

    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    public String getEndDate() {
        return endDate;
    }

    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    @Override
    public String toString() {
        return "BatchModule{" +
                "batchId=" + batchId +
                ", batchNo='" + batchNo + '\'' +
                ", startDate='" + startDate + '\'' +
                ", endDate='" + endDate + '\'' +
                '}';
    }


}
