package com.example.springboot_project.Controller;

import com.example.springboot_project.Interface.ResponseCode;
import com.example.springboot_project.Model.Database.AdminModel;
import com.example.springboot_project.Model.Database.SubjectModel;
import com.example.springboot_project.Model.Responses.ResponseModel;
import com.example.springboot_project.Services.SubjectService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

@RestController
@RequestMapping("/api/subject")
public class SubjectController {

    @Autowired
    private SubjectService subjectService;

    @PostMapping("/add/subject")
    public ResponseModel AddNewSubject(@RequestBody SubjectModel subjectModel) {
        try {
            subjectService.addSubject(subjectModel);

            ResponseModel responseModel = new ResponseModel(
                    ResponseCode.OK,
                    subjectService.addSubject(subjectModel),
                    "Successfully Added Subject Information",
                    null
            );

            return responseModel;
        } catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Internal Server Error");
        }
    }

    @PutMapping("/update/Subject")
    public ResponseModel UpdateSubject(@RequestBody SubjectModel subjectModel) {
        try {
            subjectService.updateSubjectDetails(subjectModel);

            ResponseModel responseModel = new ResponseModel(
                    ResponseCode.OK,
                    null,
                    "Successfully Updated Subject Information",
                    null
            );

            return responseModel;
        } catch (api.project.Exception.ObjectNotFoundException e) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, e.getMessage());
        } catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Internal Server Error");
        }
    }

    @GetMapping("/getAll/SubjectInfo")
    public ResponseModel GetAllSubjectInfo() {
        try {

            ResponseModel responseModel = new ResponseModel(
                    ResponseCode.OK,
                    subjectService.getAllSubject(),
                    "Successfully Got Subject Info",
                    null
            );

            return responseModel;
        } catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Internal Server Error");
        }
    }

    @GetMapping("/get/particularBatchModule/{batch}")
    public ResponseModel getParticularModules(@PathVariable String batch)  {
        try {

            subjectService.getBatchModules(batch);
            ResponseModel responseModel = new ResponseModel(
                    ResponseCode.OK,
                    subjectService.getBatchModules(batch),
                    "Successfully Got Modules Information",
                    null
            );

            return responseModel;
        } catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Internal Server Error");
        }
    }

    @DeleteMapping(value = "/deleteSubject/{id}")
    public ResponseModel DeleteSubject(@PathVariable int id) {
        try {
            subjectService.deleteSubject(id);

            ResponseModel responseModel = new ResponseModel(
                    ResponseCode.OK,
                    null,
                    "Successfully Deleted Subject Info",
                    null
            );
            return responseModel;
        } catch (api.project.Exception.ObjectNotFoundException e) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, e.getMessage());
        } catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Internal Server Error");
        }
    }
}
