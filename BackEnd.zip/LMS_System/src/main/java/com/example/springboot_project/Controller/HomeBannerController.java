package com.example.springboot_project.Controller;

import com.example.springboot_project.Interface.ResponseCode;
import com.example.springboot_project.Model.Database.SubjectModuleModel;
import com.example.springboot_project.Model.Responses.ResponseModel;
import com.example.springboot_project.Services.HomeBannerService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.server.ResponseStatusException;

@RestController
@RequestMapping("/api/homeBanner")
public class HomeBannerController {

    @Autowired
    private HomeBannerService homeBannerService;

    @PutMapping("/update/homebanner")
    public ResponseModel UpdateHomeBanner(@RequestPart(value = "file") MultipartFile file) {
        try {

            homeBannerService.updateHomeBanner(file);
            ResponseModel responseModel = new ResponseModel(
                    ResponseCode.OK,
                    null,
                    "Successfully Update Home Banner Information",
                    null
            );

            return responseModel;
        } catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Internal Server Error");
        }
    }

    @GetMapping("/get/HomeBannerInfo")
    public ResponseModel GetAllHomeBannerInfo() {
        try {

            ResponseModel responseModel = new ResponseModel(
                    ResponseCode.OK,
                    homeBannerService.getHomeBanner(),
                    "Successfully Got Home Info",
                    null
            );

            return responseModel;
        } catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Internal Server Error");
        }
    }

}
