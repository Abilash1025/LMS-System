package com.example.springboot_project.Model.Database;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity(name = "login")
public class LoginModel {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int loginId;
    private String userName;
    private String password;
    private String role;

    private int userId;

    private String batchNo;

    public LoginModel() {
    }

    public LoginModel(int loginId, String userName, String password, String role, int userId, String batchNo) {
        this.loginId = loginId;
        this.userName = userName;
        this.password = password;
        this.role = role;
        this.userId = userId;
        this.batchNo = batchNo;
    }

    public int getLoginId() {
        return loginId;
    }

    public void setLoginId(int loginId) {
        this.loginId = loginId;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public String getBatchNo() {
        return batchNo;
    }

    public void setBatchNo(String batchNo) {
        this.batchNo = batchNo;
    }

    @Override
    public String toString() {
        return "LoginModel{" +
                "loginId=" + loginId +
                ", userName='" + userName + '\'' +
                ", password='" + password + '\'' +
                ", role='" + role + '\'' +
                ", userId=" + userId +
                ", batchNo='" + batchNo + '\'' +
                '}';
    }
}
