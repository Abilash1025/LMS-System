package com.example.springboot_project.Controller;

import com.example.springboot_project.Interface.ResponseCode;
import com.example.springboot_project.Model.Database.AdminModel;
import com.example.springboot_project.Model.Database.SubjectModuleModel;
import com.example.springboot_project.Model.Responses.ResponseModel;
import com.example.springboot_project.Services.AdminService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.server.ResponseStatusException;

@RestController
@RequestMapping("/api/admin")
public class AdminController {

    @Autowired
    private AdminService adminService;

    @PostMapping("/register/Admin")
    public ResponseModel AddNewAdmin(@RequestParam("data") String adminModel, @RequestPart(value = "file") MultipartFile file) {
        try {
            ObjectMapper objectMapper = new ObjectMapper();
            AdminModel model = objectMapper.readValue(adminModel,AdminModel.class);
            adminService.addAdmin(model,file);

            ResponseModel responseModel = new ResponseModel(
                    ResponseCode.OK,
                    null,
                    "Successfully Added Admin Information",
                    "aaa"
            );

            return responseModel;
        }catch (com.example.springboot_project.Exception.AlreadyExistException e) {
                   throw new ResponseStatusException(HttpStatus.CONFLICT);
        }
        catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Internal Server Error");
        }
    }

    @PutMapping("/update/Admin")
    public ResponseModel UpdateAdmin(@RequestParam("data") String adminModel, @RequestPart(value = "file", required = false) MultipartFile file) {
        try {
            ObjectMapper objectMapper = new ObjectMapper();
            AdminModel model = objectMapper.readValue(adminModel,AdminModel.class);
            adminService.updateAdminDetails(model,file);

            ResponseModel responseModel = new ResponseModel(
                    ResponseCode.OK,
                    null,
                    "Successfully Updated Admin Information",
                    null
            );

            return responseModel;
        } catch (api.project.Exception.ObjectNotFoundException e) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, e.getMessage());
        } catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Internal Server Error");
        }
    }

    @PutMapping("/update/AdminPassword")
    public ResponseModel UpdateAdminPassword(@RequestParam("password") String password,@RequestParam("username") String username ) {
        try {

            adminService.updatePasswordDetails(password,username);

            ResponseModel responseModel = new ResponseModel(
                    ResponseCode.OK,
                    null,
                    "Successfully Updated Admin Password Information",
                    null
            );

            return responseModel;
        } catch (api.project.Exception.ObjectNotFoundException e) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, e.getMessage());
        } catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Internal Server Error");
        }
    }

    @GetMapping("/getAll/AdminInfo")
    public ResponseModel GetAllAdminInfo() {
        try {

            ResponseModel responseModel = new ResponseModel(
                    ResponseCode.OK,
                    adminService.getAllAdmin(),
                    "Successfully Got Admin Info",
                    null
            );

            return responseModel;
        } catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Internal Server Error");
        }
    }

    @GetMapping("/get/ParticularAdmin/{id}")
    public ResponseModel getGratedParticularIdAdmin(@PathVariable int id)  {
        try {

            adminService.getAdminById(id);
            ResponseModel responseModel = new ResponseModel(
                    ResponseCode.OK,
                    adminService.getAdminById(id),
                    "Successfully Got Admin Information",
                    null
            );

            return responseModel;
        } catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Internal Server Error");
        }
    }

    @DeleteMapping(value = "/deleteAdmin/{id}")
    public ResponseModel DeleteEmployee(@PathVariable int id) {
        try {
            adminService.deleteAdmin(id);

            ResponseModel responseModel = new ResponseModel(
                    ResponseCode.OK,
                    null,
                    "Successfully Deleted Admin Info",
                    null
            );
            return responseModel;
        } catch (api.project.Exception.ObjectNotFoundException e) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, e.getMessage());
        } catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Internal Server Error");
        }
    }
    @GetMapping("/login")
    public ResponseModel GetLoginResponse(@RequestParam("username") String userName, @RequestParam("password") String password) {
        try {
            ResponseModel responseModel = new ResponseModel(
                    ResponseCode.OK,
                    adminService.login(userName, password),
                    "Successfully login",
                    null
            );

            return responseModel;
        } catch (api.project.Exception.ObjectNotFoundException e) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, e.getMessage());
        } catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Internal Server Error");
        }
    }
}
