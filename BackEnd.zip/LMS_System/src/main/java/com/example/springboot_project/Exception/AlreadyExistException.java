package com.example.springboot_project.Exception;

public class AlreadyExistException extends Exception {

    public AlreadyExistException(String message) {
        super(message);
    }
}
