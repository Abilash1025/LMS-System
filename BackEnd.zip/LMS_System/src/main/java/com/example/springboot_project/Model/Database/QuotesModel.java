package com.example.springboot_project.Model.Database;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity(name = "quotes")
public class QuotesModel {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int quotesId;
    private String quotes;

    public QuotesModel(int quotesId, String quotes) {
        this.quotesId = quotesId;
        this.quotes = quotes;
    }

    public QuotesModel() {
    }

    public int getQuotesId() {
        return quotesId;
    }

    public void setQuotesId(int quotesId) {
        this.quotesId = quotesId;
    }

    public String getQuotes() {
        return quotes;
    }

    public void setQuotes(String quotes) {
        this.quotes = quotes;
    }

    @Override
    public String toString() {
        return "QuotesModel{" +
                "quotesId=" + quotesId +
                ", quotes='" + quotes + '\'' +
                '}';
    }
}
