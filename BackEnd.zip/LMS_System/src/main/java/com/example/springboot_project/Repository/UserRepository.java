package com.example.springboot_project.Repository;

import com.example.springboot_project.Model.Database.UserModel;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface UserRepository extends JpaRepository<UserModel,Integer> {

    UserModel findByUserId(int id);

    UserModel findByEmail(String email);

    boolean existsByBatch(String batch);

    boolean existsByEmail(String email);

    List<UserModel> findAllByBatch(String batch);
}

