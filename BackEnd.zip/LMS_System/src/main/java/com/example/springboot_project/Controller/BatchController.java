package com.example.springboot_project.Controller;


import com.example.springboot_project.Interface.ResponseCode;
import com.example.springboot_project.Model.Database.BatchModule;
import com.example.springboot_project.Model.Database.SubjectModel;
import com.example.springboot_project.Model.Responses.ResponseModel;
import com.example.springboot_project.Services.BatchService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

@RestController
@RequestMapping("/api/batch")
public class BatchController {

    @Autowired
    private BatchService batchService;

    @PostMapping("/add/Batch")
    public ResponseModel AddNewBatch(@RequestBody BatchModule batchModule) {
        try {
            batchService.addBatch(batchModule);

            ResponseModel responseModel = new ResponseModel(
                    ResponseCode.OK,
                    batchService.addBatch(batchModule),
                    "Successfully Added Batch Information",
                    null
            );

            return responseModel;
        } catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Internal Server Error");
        }
    }


    @GetMapping("/getAll/BatchInfo")
    public ResponseModel GetAllBatchInfo() {
        try {

            ResponseModel responseModel = new ResponseModel(
                    ResponseCode.OK,
                    batchService.getAllBatch(),
                    "Successfully Got Batch Info",
                    null
            );

            return responseModel;
        } catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Internal Server Error");
        }
    }
}
