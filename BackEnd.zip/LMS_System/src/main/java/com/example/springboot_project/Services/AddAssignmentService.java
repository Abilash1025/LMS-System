package com.example.springboot_project.Services;

import com.example.springboot_project.Model.Database.*;
import com.example.springboot_project.Repository.AddAssignmentRepository;
import com.example.springboot_project.Repository.AssignmentRepository;
import com.example.springboot_project.Repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.util.ArrayList;
import java.util.List;

@Service
public class AddAssignmentService {

    @Autowired
    private AddAssignmentRepository addAssignmentRepository;

    @Autowired
    private AmazonService amazonService;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private AssignmentRepository assignmentRepository;

    public void addAssignment(AddAssignmentModule addAssignmentModule, MultipartFile file) throws Exception {
        if (file != null) {

            String fileUrl = String.valueOf(this.amazonService.UploadFile(file, "assignment").get());

            if (fileUrl != "") {
                AddAssignmentModule moduleModel= new AddAssignmentModule();

                moduleModel.setDoc(fileUrl);
                moduleModel.setModule(addAssignmentModule.getModule());
                moduleModel.setBatch(addAssignmentModule.getBatch());
                moduleModel.setTopic(addAssignmentModule.getTopic());
                moduleModel.setDeadline(addAssignmentModule.getDeadline());
                moduleModel.setComment(addAssignmentModule.getComment());
                moduleModel.setUploadtype(addAssignmentModule.getUploadtype());

                addAssignmentRepository.save(moduleModel);
                  List<UserModel> userModels = userRepository.findAllByBatch(addAssignmentModule.getBatch());

                for(int i=0;i<userModels.size();i++){
                    AssignmentModel model= new AssignmentModel();
                        model.setBriefDoc(fileUrl);
                    model.setModule(addAssignmentModule.getModule());
                    model.setBatch(addAssignmentModule.getBatch());
                    model.setTopic(addAssignmentModule.getTopic());
                    model.setDeadline(addAssignmentModule.getDeadline());
                    model.setComment(addAssignmentModule.getComment());
                    model.setUploadType(addAssignmentModule.getUploadtype());
                    model.setAssigmentFileId(moduleModel.getAssigmentFileId());
                    model.setStudentId(userModels.get(i).getUserId());
                    model.setStudentName(userModels.get(i).getFullName());
                    model.setStatus("NEW");

                    assignmentRepository.save(model);
                }

            } else {
                throw new Exception("Amazon S3 issue in storing image");
            }
        }

    }

    public List getAllAssignment(){
        List<AddAssignmentModule> addAssignmentModules = addAssignmentRepository.findAll();

        return addAssignmentModules;
    }

    public List getOneAssignmentModule(int id) throws api.project.Exception.ObjectNotFoundException {
        if (addAssignmentRepository.existsById(id)) {
            AddAssignmentModule addAssignmentModule= addAssignmentRepository.findByAssigmentFileId(id);
            List assignmentInfo = new ArrayList();
            assignmentInfo.add(addAssignmentModule);

            return assignmentInfo;
        } else {
            throw new api.project.Exception.ObjectNotFoundException("Incorrect Assignment Id to Retrieved a Assignment Info");
        }
    }

    public List getBatchAssignmentModule(String batch) throws api.project.Exception.ObjectNotFoundException {
        if (addAssignmentRepository.existsByBatch(batch)) {
            AddAssignmentModule addAssignmentModule= addAssignmentRepository.findAllByBatch(batch);
//add stat


            List assignmentInfo = new ArrayList();
            assignmentInfo.add(addAssignmentModule);

            return assignmentInfo;
        } else {
            throw new api.project.Exception.ObjectNotFoundException("Incorrect Assignment Id to Retrieved a Assignment Info");
        }
    }


    public void updateAssignmentDetails(AddAssignmentModule assignment) throws api.project.Exception.ObjectNotFoundException {
        if (addAssignmentRepository.existsById(assignment.getAssigmentFileId())) {
            AddAssignmentModule addAssignmentModule = addAssignmentRepository.findByAssigmentFileId(assignment.getAssigmentFileId());
            List<AssignmentModel> assignmentModel=assignmentRepository.findAllByAssigmentFileId(assignment.getAssigmentFileId());
            if (assignment.getTopic() != null && assignment.getTopic().length() > 0) {
                addAssignmentModule.setTopic(assignment.getTopic());
            }
            if (assignment.getBatch() != null && assignment.getBatch().length() > 0) {
                addAssignmentModule.setBatch(assignment.getBatch());
            }
            if (assignment.getModule() != null && assignment.getModule().length() > 0) {
                addAssignmentModule.setModule(assignment.getModule());
            }
            if (assignment.getDeadline() != null && assignment.getDeadline().length() > 0) {
                addAssignmentModule.setDeadline(assignment.getDeadline());
            }
            if (assignment.getComment() != null && assignment.getComment().length() > 0) {
                addAssignmentModule.setComment(assignment.getComment());
            }
            for(int i=0;i<assignmentModel.size();i++){
                if (assignment.getTopic() != null && assignment.getTopic().length() > 0) {
                    assignmentModel.get(i).setTopic(assignment.getTopic());
                }
                if (assignment.getBatch() != null && assignment.getBatch().length() > 0) {
                    assignmentModel.get(i).setBatch(assignment.getBatch());
                }
                if (assignment.getModule() != null && assignment.getModule().length() > 0) {
                    assignmentModel.get(i).setModule(assignment.getModule());
                }
                if (assignment.getDeadline() != null && assignment.getDeadline().length() > 0) {
                    assignmentModel.get(i).setDeadline(assignment.getDeadline());
                }
                if (assignment.getComment() != null && assignment.getComment().length() > 0) {
                    assignmentModel.get(i).setComment(assignment.getComment());
                }
                assignmentRepository.save(assignmentModel.get(i));
            }



            addAssignmentRepository.save(addAssignmentModule);

        } else {
            throw new api.project.Exception.ObjectNotFoundException("Assignment info not found");
        }
    }

    public void deleteAssignment(int id) throws api.project.Exception.ObjectNotFoundException {
        if(addAssignmentRepository.existsById(id) ){
            assignmentRepository.deleteAllByAssigmentFileId(id);
            addAssignmentRepository.deleteById(id);

        }
        else{
            throw new api.project.Exception.ObjectNotFoundException("Id is not found");
        }
    }

}
