package com.example.springboot_project.Model.Database;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity(name = "assignmentFiles")
public class AddAssignmentModule {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int assigmentFileId;
    private String topic;
    private String module;
    private String batch;
    private String uploadtype;
    private String doc;
    private String deadline;
    private String comment;

    public AddAssignmentModule() {
    }

    public AddAssignmentModule(int assigmentFileId, String topic, String module, String batch, String uploadtype, String doc, String deadline, String comment) {
        this.assigmentFileId = assigmentFileId;
        this.topic = topic;
        this.module = module;
        this.batch = batch;
        this.uploadtype = uploadtype;
        this.doc = doc;
        this.deadline = deadline;
        this.comment = comment;
    }

    public int getAssigmentFileId() {
        return assigmentFileId;
    }

    public void setAssigmentFileId(int assigmentFileId) {
        this.assigmentFileId = assigmentFileId;
    }

    public String getTopic() {
        return topic;
    }

    public void setTopic(String topic) {
        this.topic = topic;
    }

    public String getModule() {
        return module;
    }

    public void setModule(String module) {
        this.module = module;
    }

    public String getBatch() {
        return batch;
    }

    public void setBatch(String batch) {
        this.batch = batch;
    }

    public String getUploadtype() {
        return uploadtype;
    }

    public void setUploadtype(String uploadtype) {
        this.uploadtype = uploadtype;
    }

    public String getDoc() {
        return doc;
    }

    public void setDoc(String doc) {
        this.doc = doc;
    }

    public String getDeadline() {
        return deadline;
    }

    public void setDeadline(String deadline) {
        this.deadline = deadline;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    @Override
    public String toString() {
        return "AddAssignmentModule{" +
                "assigmentFileId=" + assigmentFileId +
                ", topic='" + topic + '\'' +
                ", module='" + module + '\'' +
                ", batch='" + batch + '\'' +
                ", uploadtype='" + uploadtype + '\'' +
                ", doc='" + doc + '\'' +
                ", deadline='" + deadline + '\'' +
                ", comment='" + comment + '\'' +
                '}';
    }
}
