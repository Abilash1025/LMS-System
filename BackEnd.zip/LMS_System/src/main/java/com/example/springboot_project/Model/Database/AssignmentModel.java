package com.example.springboot_project.Model.Database;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity(name = "assignment")
public class AssignmentModel {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int assignmentId;
    private int assigmentFileId;
    private String topic;
    private String module;
    private String batch;
    private String uploadType;
    private String briefDoc;
    private String deadline;
    private String comment;
    private int studentId;
    private String submittedDoc;
    private String status;
    private String marks;
    private String commentt;

    private String studentName;

    private String submittedTime;
    public AssignmentModel() {
    }

    public AssignmentModel(int assignmentId, int assigmentFileId, String topic, String module, String batch, String uploadType, String briefDoc, String deadline, String comment, int studentId, String submittedDoc, String status, String marks, String commentt, String studentName, String submittedTime) {
        this.assignmentId = assignmentId;
        this.assigmentFileId = assigmentFileId;
        this.topic = topic;
        this.module = module;
        this.batch = batch;
        this.uploadType = uploadType;
        this.briefDoc = briefDoc;
        this.deadline = deadline;
        this.comment = comment;
        this.studentId = studentId;
        this.submittedDoc = submittedDoc;
        this.status = status;
        this.marks = marks;
        this.commentt = commentt;
        this.studentName = studentName;
        this.submittedTime = submittedTime;
    }

    public int getAssigmentFileId() {
        return assigmentFileId;
    }

    public void setAssigmentFileId(int assigmentFileId) {
        this.assigmentFileId = assigmentFileId;
    }

    public String getTopic() {
        return topic;
    }

    public void setTopic(String topic) {
        this.topic = topic;
    }

    public String getModule() {
        return module;
    }

    public void setModule(String module) {
        this.module = module;
    }

    public String getBatch() {
        return batch;
    }

    public void setBatch(String batch) {
        this.batch = batch;
    }

    public String getUploadType() {
        return uploadType;
    }

    public void setUploadType(String uploadType) {
        this.uploadType = uploadType;
    }

    public String getBriefDoc() {
        return briefDoc;
    }

    public void setBriefDoc(String briefDoc) {
        this.briefDoc = briefDoc;
    }

    public String getDeadline() {
        return deadline;
    }

    public void setDeadline(String deadline) {
        this.deadline = deadline;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public String getSubmittedTime() {
        return submittedTime;
    }

    public void setSubmittedTime(String submittedTime) {
        this.submittedTime = submittedTime;
    }

    public int getAssignmentId() {
        return assignmentId;
    }

    public void setAssignmentId(int assignmentId) {
        this.assignmentId = assignmentId;
    }

    public int getStudentId() {
        return studentId;
    }

    public void setStudentId(int studentId) {
        this.studentId = studentId;
    }

    public String getSubmittedDoc() {
        return submittedDoc;
    }

    public void setSubmittedDoc(String submittedDoc) {
        this.submittedDoc = submittedDoc;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getMarks() {
        return marks;
    }

    public void setMarks(String marks) {
        this.marks = marks;
    }

    public String getCommentt() {
        return commentt;
    }

    public void setCommentt(String commentt) {
        this.commentt = commentt;
    }

    public String getStudentName() {
        return studentName;
    }

    public void setStudentName(String studentName) {
        this.studentName = studentName;
    }

    @Override
    public String toString() {
        return "AssignmentModel{" +
                "assignmentId=" + assignmentId +
                ", assigmentFileId=" + assigmentFileId +
                ", topic='" + topic + '\'' +
                ", module='" + module + '\'' +
                ", batch='" + batch + '\'' +
                ", uploadType='" + uploadType + '\'' +
                ", briefDoc='" + briefDoc + '\'' +
                ", deadline='" + deadline + '\'' +
                ", comment='" + comment + '\'' +
                ", studentId=" + studentId +
                ", submittedDoc='" + submittedDoc + '\'' +
                ", status='" + status + '\'' +
                ", marks='" + marks + '\'' +
                ", commentt='" + commentt + '\'' +
                ", studentName='" + studentName + '\'' +
                ", submittedTime='" + submittedTime + '\'' +
                '}';
    }
}
