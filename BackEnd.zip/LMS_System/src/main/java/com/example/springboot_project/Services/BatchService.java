package com.example.springboot_project.Services;

import com.example.springboot_project.Model.Database.BatchModule;
import com.example.springboot_project.Model.Database.SubjectModel;
import com.example.springboot_project.Repository.BatchRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class BatchService {

    @Autowired
    BatchRepository batchRepository;
    public List addBatch (BatchModule batchModule){

        batchRepository.save(batchModule);

        List batch = new ArrayList();
        batch.add(batchModule);
        return batch;
    }
    public List getAllBatch(){
        List<BatchModule> batchModules = batchRepository.findAll();

        return batchModules;
    }
}
