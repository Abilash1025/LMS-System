package com.example.springboot_project.Services;

import com.amazonaws.AmazonServiceException;
import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3Client;
import com.amazonaws.services.s3.model.DeleteObjectRequest;
import com.amazonaws.services.s3.model.PutObjectRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.PostConstruct;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Date;
import java.util.concurrent.CompletableFuture;

@Service
public class AmazonService {
    private AmazonS3 s3client;

    @Value("${amazonProperties.endpointUrl}")
    private String endpointUrl;
    @Value("${amazonProperties.bucketName}")
    private String bucketName;
    @Value("${amazonProperties.accessKey}")
    private String accessKey;
    @Value("${amazonProperties.secretKey}")
    private String secretKey;

    private Logger logger = LoggerFactory.getLogger(AmazonService.class);

    @PostConstruct
    private void InitializeAmazon(){
        AWSCredentials credentials = new BasicAWSCredentials(this.accessKey,this.secretKey);
        this.s3client = new AmazonS3Client(credentials);
    }

    @Async
    public CompletableFuture<String> UploadFile(MultipartFile multipartFile, String FolderName) throws IOException{
        String fileUrl="";

        try{
            File file= ConvertMultiPartToFile(multipartFile);
            String fileName= GenerateFileName(multipartFile);
            fileUrl = endpointUrl+"/"+FolderName+"/"+ fileName;
            UploadFileTos3bucket(fileName,file,FolderName);
            file.delete();
        }
        catch (AmazonServiceException ase){
            logger.info("Request ID:"+ase.getRequestId());
        }

        return CompletableFuture.completedFuture(fileUrl);
    }

    @Async
    public CompletableFuture<String> DeleteFileFromS3Bucket(final String fileName, String FolderName){
        logger.info("Deleting file with the name"+ fileName);
        final DeleteObjectRequest deleteObjectRequest = new DeleteObjectRequest(bucketName+"/"+FolderName,fileName);
        s3client.deleteObject(deleteObjectRequest);
        logger.info("File deleted successfully");
        return CompletableFuture.completedFuture("true");
    }

    private void UploadFileTos3bucket(String filename, File file,String FolderName){
        s3client.putObject(
                new PutObjectRequest(bucketName+"/"+FolderName, filename, file));
    }

    private String GenerateFileName(MultipartFile multipart){
        return new Date().getTime()+"_"+multipart.getOriginalFilename().replace(" ","_");
    }

    private File ConvertMultiPartToFile(MultipartFile file) throws IOException{
        File convFile=new File(file.getOriginalFilename());
        FileOutputStream fos= new FileOutputStream(convFile);
        fos.write(file.getBytes());
        fos.close();
        return convFile;
    }
}
