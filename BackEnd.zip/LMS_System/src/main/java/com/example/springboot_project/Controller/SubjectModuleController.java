package com.example.springboot_project.Controller;

import com.example.springboot_project.Interface.ResponseCode;
import com.example.springboot_project.Model.Database.SubjectModel;
import com.example.springboot_project.Model.Database.SubjectModuleModel;
import com.example.springboot_project.Model.Responses.ResponseModel;
import com.example.springboot_project.Services.SubjectModuleService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.server.ResponseStatusException;

@RestController
@RequestMapping("/api/subject")
public class SubjectModuleController {

    @Autowired
    private SubjectModuleService subjectModuleService;


    @PostMapping("/add/SubjectModule")
    public ResponseModel AddNewSubjectModule(@RequestParam("data") String subjectModuleModel, @RequestPart(value = "file") MultipartFile file) {
        try {
            ObjectMapper objectMapper = new ObjectMapper();
            SubjectModuleModel moduleModel = objectMapper.readValue(subjectModuleModel,SubjectModuleModel.class);
            subjectModuleService.addSubjectModule(moduleModel,file);

            ResponseModel responseModel = new ResponseModel(
                    ResponseCode.OK,
                    null,
                    "Successfully Added Subject Module Information",
                    null
            );

            return responseModel;
        } catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Internal Server Error");
        }
    }

    @PutMapping("/update/SubjectModule")
    public ResponseModel UpdateSubjectModule(@RequestBody SubjectModuleModel subjectModuleModel) {
        try {
            subjectModuleService.updateSubjectModuleDetails(subjectModuleModel);

            ResponseModel responseModel = new ResponseModel(
                    ResponseCode.OK,
                    null,
                    "Successfully Updated Subject Module Information",
                    null
            );

            return responseModel;
        } catch (api.project.Exception.ObjectNotFoundException e) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, e.getMessage());
        } catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Internal Server Error");
        }
    }

    @GetMapping("/getAll/SubjectModuleInfo")
    public ResponseModel GetAllSubjectModuleInfo() {
        try {

            ResponseModel responseModel = new ResponseModel(
                    ResponseCode.OK,
                    subjectModuleService.getAllSubjectModule(),
                    "Successfully Got Subject Info",
                    null
            );

            return responseModel;
        } catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Internal Server Error");
        }
    }

    @GetMapping("/get/particularBatchSubject/{batch}/{module}")
    public ResponseModel getParticularModules(@PathVariable String batch,@PathVariable String module)  {
        try {

            subjectModuleService.getSubjectBatchModules(batch,module);
            ResponseModel responseModel = new ResponseModel(
                    ResponseCode.OK,
                    subjectModuleService.getSubjectBatchModules(batch,module),
                    "Successfully Got Modules Information",
                    null
            );

            return responseModel;
        } catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Internal Server Error");
        }
    }

    @GetMapping("/get/SubjectModule/{id}")
    public ResponseModel GetParticularModule(@PathVariable int id) {
        try {
            ResponseModel responseModel = new ResponseModel(
                    ResponseCode.OK,
                    subjectModuleService.getOneSubjectModule(id),
                    "Successfully Retrieved Module Info",
                    null
            );
            return responseModel;
        } catch (api.project.Exception.ObjectNotFoundException e) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, e.getMessage());
        } catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Internal Server Error");
        }
    }

    @DeleteMapping(value = "/deleteSubjectModule/{id}")
    public ResponseModel DeleteSubjectModule(@PathVariable int id) {
        try {
            subjectModuleService.deleteSubjectModule(id);

            ResponseModel responseModel = new ResponseModel(
                    ResponseCode.OK,
                    null,
                    "Successfully Deleted Subject Module Info",
                    null
            );
            return responseModel;
        } catch (api.project.Exception.ObjectNotFoundException e) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, e.getMessage());
        } catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Internal Server Error");
        }
    }
}
