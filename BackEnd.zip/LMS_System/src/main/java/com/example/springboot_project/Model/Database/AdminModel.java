package com.example.springboot_project.Model.Database;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity(name = "admin")
public class AdminModel {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int adminId;
    private String fullName;
    private String telephoneNumber;
    private String address;
    private String gender;
    private String email;
    private String password;

    private String image;


    public AdminModel() {
    }

    public AdminModel(int adminId, String fullName, String telephoneNumber, String address,  String gender, String email, String password, String image) {
        this.adminId = adminId;
        this.fullName = fullName;
        this.telephoneNumber = telephoneNumber;
        this.address = address;
        this.gender = gender;
        this.email = email;
        this.password = password;
        this.image = image;
    }

    public int getAdminId() {
        return adminId;
    }

    public void setAdminId(int employeeId) {
        this.adminId = employeeId;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getTelephoneNumber() {
        return telephoneNumber;
    }

    public void setTelephoneNumber(String telephoneNumber) {
        this.telephoneNumber = telephoneNumber;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    @Override
    public String toString() {
        return "AdminModel{" +
                "adminId=" + adminId +
                ", fullName='" + fullName + '\'' +
                ", telephoneNumber='" + telephoneNumber + '\'' +
                ", address='" + address + '\'' +
                ", gender='" + gender + '\'' +
                ", email='" + email + '\'' +
                ", password='" + password + '\'' +
                ", image='" + image + '\'' +
                '}';
    }
}
