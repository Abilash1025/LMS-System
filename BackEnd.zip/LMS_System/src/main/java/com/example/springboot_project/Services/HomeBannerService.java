package com.example.springboot_project.Services;

import com.example.springboot_project.Model.Database.HomeBannerModel;
import com.example.springboot_project.Model.Database.SubjectModuleModel;
import com.example.springboot_project.Repository.HomeBannerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

@Service
public class HomeBannerService {

    @Autowired
    private HomeBannerRepository homeBannerRepository;

    @Autowired
    private AmazonService amazonService;

    public void updateHomeBanner( MultipartFile file) throws Exception {
        if (file != null) {

            String fileUrl = String.valueOf(this.amazonService.UploadFile(file, "homebanner").get());

            if (fileUrl != "") {
                HomeBannerModel homeBannerModel = homeBannerRepository.findByHomeBannerId(11);

                homeBannerModel.setImage(fileUrl);

                homeBannerRepository.save(homeBannerModel);
            } else {
                throw new Exception("Amazon S3 issue in storing image");
            }
        }
    }


    public List getHomeBanner(){
        List<HomeBannerModel> homeBannerModels = homeBannerRepository.findAll();

        return homeBannerModels;
    }

}
