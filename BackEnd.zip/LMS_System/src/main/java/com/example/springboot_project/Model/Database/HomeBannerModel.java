package com.example.springboot_project.Model.Database;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity(name = "banner")
public class HomeBannerModel {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int homeBannerId;
    private String image;

    public HomeBannerModel() {
    }

    public HomeBannerModel(int homeBannerId, String image) {
        this.homeBannerId = homeBannerId;
        this.image = image;
    }

    public int getHomeBannerId() {
        return homeBannerId;
    }

    public void setHomeBannerId(int homeBannerId) {
        this.homeBannerId = homeBannerId;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    @Override
    public String toString() {
        return "HomeBannerModel{" +
                "homeBannerId=" + homeBannerId +
                ", image='" + image + '\'' +
                '}';
    }
}
