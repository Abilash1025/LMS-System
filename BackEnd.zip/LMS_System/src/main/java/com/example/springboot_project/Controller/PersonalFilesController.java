package com.example.springboot_project.Controller;

import com.example.springboot_project.Interface.ResponseCode;
import com.example.springboot_project.Model.Database.PersonalFileModel;
import com.example.springboot_project.Model.Database.SubjectModuleModel;
import com.example.springboot_project.Model.Responses.ResponseModel;
import com.example.springboot_project.Services.PersonalFileServices;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.server.ResponseStatusException;

@RestController
@RequestMapping("/api/personal")
public class PersonalFilesController {

    @Autowired
    private PersonalFileServices personalFileServices;

    @PostMapping("/add/PersonalFile")
    public ResponseModel AddNewPersonalFile(@RequestParam("data") String personalFileModel,@RequestParam("user") String user, @RequestPart(value = "file") MultipartFile file) {
        try {
            ObjectMapper objectMapper = new ObjectMapper();
            PersonalFileModel fileModel = objectMapper.readValue(personalFileModel,PersonalFileModel.class);
            personalFileServices.addPersonal(fileModel,user,file);

            ResponseModel responseModel = new ResponseModel(
                    ResponseCode.OK,
                    null,
                    "Successfully Added Personal File Information",
                    null
            );

            return responseModel;
        } catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Internal Server Error");
        }
    }

    @GetMapping("/get/particularPersonalFile/{user}")
    public ResponseModel getParticularPersonalFiles(@PathVariable String user)  {
        try {

            personalFileServices.getParticularUserFile(user);
            ResponseModel responseModel = new ResponseModel(
                    ResponseCode.OK,
                    personalFileServices.getParticularUserFile(user),
                    "Successfully Got Personal Information",
                    null
            );

            return responseModel;
        } catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Internal Server Error");
        }
    }

    @DeleteMapping(value = "/deleteFile/{id}")
    public ResponseModel DeletePersonalFile(@PathVariable int id) {
        try {
            personalFileServices.deletePersonalFile(id);

            ResponseModel responseModel = new ResponseModel(
                    ResponseCode.OK,
                    null,
                    "Successfully Deleted Personal File Info",
                    null
            );
            return responseModel;
        } catch (api.project.Exception.ObjectNotFoundException e) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, e.getMessage());
        } catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Internal Server Error");
        }
    }

}
