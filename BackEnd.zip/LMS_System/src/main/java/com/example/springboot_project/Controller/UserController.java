package com.example.springboot_project.Controller;

import com.example.springboot_project.Interface.ResponseCode;
import com.example.springboot_project.Model.Database.AdminModel;
import com.example.springboot_project.Model.Database.UserModel;
import com.example.springboot_project.Model.Responses.ResponseModel;
import com.example.springboot_project.Services.UserService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.server.ResponseStatusException;

@RestController
@RequestMapping("/api/user")
public class UserController {

    @Autowired
    private UserService userService;

    @PostMapping("/register/User")
    public ResponseModel AddNewUser(@RequestParam("data") String userModel, @RequestPart(value = "file") MultipartFile file) {
        try {

            ObjectMapper objectMapper = new ObjectMapper();
            UserModel model = objectMapper.readValue(userModel,UserModel.class);
            userService.addUser(model,file);

            ResponseModel responseModel = new ResponseModel(
                    ResponseCode.OK,
                    null,
                    "Successfully Added User Information",
                    null
            );

            return responseModel;
        } catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Internal Server Error");
        }
    }


    @PutMapping("/update/UserPassword")
    public ResponseModel UpdateUserPassword(@RequestParam("password") String password,@RequestParam("username") String username ) {
        try {

            userService.updatePasswordDetails(password,username);

            ResponseModel responseModel = new ResponseModel(
                    ResponseCode.OK,
                    null,
                    "Successfully Updated User Password Information",
                    null
            );

            return responseModel;
        } catch (api.project.Exception.ObjectNotFoundException e) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, e.getMessage());
        } catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Internal Server Error");
        }
    }


    @PutMapping("/update/User")
    public ResponseModel UpdateUser(@RequestParam("data") String userModel, @RequestPart(value = "file", required = false) MultipartFile file) {
        try {

            ObjectMapper objectMapper = new ObjectMapper();
            UserModel model = objectMapper.readValue(userModel,UserModel.class);
            userService.updateUserDetails(model,file);


            ResponseModel responseModel = new ResponseModel(
                    ResponseCode.OK,
                    null,
                    "Successfully Updated User Information",
                    null
            );

            return responseModel;
        } catch (api.project.Exception.ObjectNotFoundException e) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, e.getMessage());
        } catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Internal Server Error");
        }
    }


    @GetMapping("/getAll/UserInfo")
    public ResponseModel GetAllUserInfo() {
        try {

            ResponseModel responseModel = new ResponseModel(
                    ResponseCode.OK,
                    userService.getAllUser(),
                    "Successfully Got User Info",
                    null
            );

            return responseModel;
        } catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Internal Server Error");
        }
    }


    @GetMapping("/get/ParticularUser/{id}")
    public ResponseModel getGratedParticularIdUser(@PathVariable int id)  {
        try {

            userService.getUserById(id);
            ResponseModel responseModel = new ResponseModel(
                    ResponseCode.OK,
                    userService.getUserById(id),
                    "Successfully Got User Information",
                    null
            );

            return responseModel;
        } catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Internal Server Error");
        }
    }


    @DeleteMapping(value = "/deleteUser/{id}")
    public ResponseModel DeleteUser(@PathVariable int id) {
        try {
            userService.deleteUser(id);

            ResponseModel responseModel = new ResponseModel(
                    ResponseCode.OK,
                    null,
                    "Successfully Deleted User Info",
                    null
            );
            return responseModel;
        } catch (api.project.Exception.ObjectNotFoundException e) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, e.getMessage());
        } catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Internal Server Error");
        }
    }
}
